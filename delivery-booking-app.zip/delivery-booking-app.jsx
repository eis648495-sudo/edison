import React, { useState, useEffect, useMemo } from "react";
import { Package, Truck, MapPin, Clock, Send, Loader2, ChevronDown, ChevronUp, RefreshCw } from "lucide-react";

/* ---------- static data ---------- */

const SIZES = [
  { id: "envelope", label: "Envelope", hint: "up to 0.5kg", base: 80 },
  { id: "small", label: "Small Box", hint: "up to 2kg", base: 120 },
  { id: "medium", label: "Medium Box", hint: "up to 5kg", base: 180 },
  { id: "large", label: "Large Box", hint: "up to 15kg", base: 260 },
];

const SERVICES = [
  { id: "standard", label: "Standard", hint: "2–3 days", mult: 1 },
  { id: "express", label: "Express", hint: "Next day", mult: 1.6 },
];

const SLOTS = [
  { id: "morning", label: "8:00–11:00" },
  { id: "midday", label: "11:00–14:00" },
  { id: "afternoon", label: "14:00–17:00" },
  { id: "evening", label: "17:00–20:00" },
];

const STATUS_ORDER = ["pending", "picked_up", "in_transit", "delivered", "cancelled"];

const STATUS_META = {
  pending: { label: "Booked", stamp: "BOOKED", color: "#C97F0E" },
  picked_up: { label: "Picked up", stamp: "PICKED UP", color: "#16233D" },
  in_transit: { label: "In transit", stamp: "IN TRANSIT", color: "#2B5C8A" },
  delivered: { label: "Delivered", stamp: "DELIVERED", color: "#2F6B4F" },
  cancelled: { label: "Cancelled", stamp: "CANCELLED", color: "#B23A2E" },
};

const INITIAL_DRAFT = {
  senderName: "", senderPhone: "", senderAddress: "",
  receiverName: "", receiverPhone: "", receiverAddress: "",
  size: "", weight: "", fragile: false, service: "standard",
  date: "", slot: "", notes: "",
};

/* ---------- helpers ---------- */

function genTracking() {
  const t = Date.now().toString(36).toUpperCase().slice(-5);
  const r = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `PL-${t}${r}`;
}

function estimatePrice(draft) {
  const size = SIZES.find((s) => s.id === draft.size);
  if (!size) return 0;
  const service = SERVICES.find((s) => s.id === draft.service) || SERVICES[0];
  const fragileFee = draft.fragile ? 30 : 0;
  return Math.round(size.base * service.mult + fragileFee);
}

function truncate(str, n) {
  if (!str) return "";
  return str.length > n ? str.slice(0, n - 1) + "…" : str;
}

function formatDate(d) {
  if (!d) return "";
  const dt = new Date(d + "T00:00:00");
  if (isNaN(dt.getTime())) return "";
  return dt.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

function cityOf(addr) {
  if (!addr) return "";
  return addr.split(",")[0].trim();
}

/* ---------- small components ---------- */

function Barcode({ value }) {
  const bars = Array.from(value || "PLDRAFT0000").map((c) => (c.charCodeAt(0) % 4) + 1);
  return (
    <div className="barcode" aria-hidden="true">
      {bars.map((w, i) => (
        <span key={i} style={{ width: w * 3 + "px" }} />
      ))}
    </div>
  );
}

function Waybill({ booking, draftMode }) {
  const meta = draftMode ? { stamp: "DRAFT", color: "#8A8676" } : STATUS_META[booking.status] || STATUS_META.pending;
  const sizeInfo = SIZES.find((s) => s.id === booking.pkg?.size);
  const serviceInfo = SERVICES.find((s) => s.id === booking.pkg?.service);
  const slotInfo = SLOTS.find((s) => s.id === booking.slot);

  return (
    <div className="waybill">
      <div className="waybill-stamp" style={{ color: meta.color, borderColor: meta.color }}>
        {meta.stamp}
      </div>
      <div className="waybill-eyebrow">Waybill</div>
      <div className="waybill-tracking">{booking.tracking || "—"}</div>

      <div className="waybill-route">
        <div className="route-point">
          <span className="route-label">From</span>
          <span className="route-value">{booking.sender?.name || "Sender"}</span>
          <span className="route-sub">{truncate(booking.sender?.address, 30) || "Pickup address"}</span>
        </div>
        <Truck size={18} className="route-arrow" aria-hidden="true" />
        <div className="route-point">
          <span className="route-label">To</span>
          <span className="route-value">{booking.receiver?.name || "Receiver"}</span>
          <span className="route-sub">{truncate(booking.receiver?.address, 30) || "Delivery address"}</span>
        </div>
      </div>

      <div className="waybill-divider">
        <span className="notch left" />
        <span className="notch right" />
      </div>

      <div className="waybill-meta-grid">
        <div>
          <span className="meta-label">Package</span>
          <span className="meta-value">{sizeInfo ? sizeInfo.label : "—"}</span>
        </div>
        <div>
          <span className="meta-label">Service</span>
          <span className="meta-value">{serviceInfo ? serviceInfo.label : "—"}</span>
        </div>
        <div>
          <span className="meta-label">Pickup</span>
          <span className="meta-value">
            {booking.date ? formatDate(booking.date) : "—"}
            {slotInfo ? ` · ${slotInfo.label}` : ""}
          </span>
        </div>
        <div>
          <span className="meta-label">Est. rate</span>
          <span className="meta-value price">₱{booking.price || 0}</span>
        </div>
      </div>

      <Barcode value={booking.tracking} />
    </div>
  );
}

function MiniTicket({ booking }) {
  const meta = STATUS_META[booking.status] || STATUS_META.pending;
  const slotInfo = SLOTS.find((s) => s.id === booking.slot);
  return (
    <div className="mini-ticket">
      <div className="mini-top">
        <span className="mini-tracking">{booking.tracking}</span>
        <span className="mini-stamp" style={{ color: meta.color, borderColor: meta.color }}>
          {meta.stamp}
        </span>
      </div>
      <div className="mini-route">To {truncate(booking.receiver?.address, 34)}</div>
      <div className="mini-slot">
        {formatDate(booking.date)}
        {slotInfo ? ` · ${slotInfo.label}` : ""}
      </div>
    </div>
  );
}

/* ---------- main app ---------- */

export default function DeliveryBookingApp() {
  const [view, setView] = useState("book");
  const [bookings, setBookings] = useState([]);
  const [myIds, setMyIds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState(INITIAL_DRAFT);
  const [previewTracking, setPreviewTracking] = useState(() => genTracking());
  const [submitting, setSubmitting] = useState(false);
  const [confirmedTracking, setConfirmedTracking] = useState(null);
  const [storageError, setStorageError] = useState(false);
  const [filter, setFilter] = useState("all");
  const [expandedId, setExpandedId] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function loadAll() {
      setLoading(true);
      try {
        const res = await window.storage.get("bookings-list", true);
        if (!cancelled) setBookings(res ? JSON.parse(res.value) : []);
      } catch (e) {
        if (!cancelled) setBookings([]);
      }
      try {
        const res2 = await window.storage.get("my-tracking-ids", false);
        if (!cancelled) setMyIds(res2 ? JSON.parse(res2.value) : []);
      } catch (e) {
        if (!cancelled) setMyIds([]);
      }
      if (!cancelled) setLoading(false);
    }
    loadAll();
    return () => { cancelled = true; };
  }, []);

  const price = useMemo(() => estimatePrice(draft), [draft]);

  const isValid =
    draft.senderName.trim() && draft.senderAddress.trim() &&
    draft.receiverName.trim() && draft.receiverAddress.trim() &&
    draft.size && draft.date && draft.slot;

  const previewBooking = {
    tracking: previewTracking,
    sender: { name: draft.senderName, address: draft.senderAddress },
    receiver: { name: draft.receiverName, address: draft.receiverAddress },
    pkg: { size: draft.size, service: draft.service },
    date: draft.date, slot: draft.slot, price,
  };

  function setField(key, value) {
    setDraft((d) => ({ ...d, [key]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!isValid || submitting) return;
    setSubmitting(true);
    setStorageError(false);

    const booking = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      tracking: previewTracking,
      sender: { name: draft.senderName.trim(), phone: draft.senderPhone.trim(), address: draft.senderAddress.trim() },
      receiver: { name: draft.receiverName.trim(), phone: draft.receiverPhone.trim(), address: draft.receiverAddress.trim() },
      pkg: { size: draft.size, weight: draft.weight, fragile: draft.fragile, service: draft.service },
      date: draft.date, slot: draft.slot, notes: draft.notes.trim(),
      price, status: "pending", createdAt: new Date().toISOString(),
    };

    const newList = [booking, ...bookings];
    const newMyIds = [booking.id, ...myIds];

    try {
      await window.storage.set("bookings-list", JSON.stringify(newList), true);
      await window.storage.set("my-tracking-ids", JSON.stringify(newMyIds), false);
      setBookings(newList);
      setMyIds(newMyIds);
      setConfirmedTracking(booking.tracking);
      setDraft(INITIAL_DRAFT);
      setPreviewTracking(genTracking());
    } catch (err) {
      setStorageError(true);
    }
    setSubmitting(false);
  }

  async function updateStatus(id, newStatus) {
    setUpdatingId(id);
    const newList = bookings.map((b) => (b.id === id ? { ...b, status: newStatus } : b));
    try {
      await window.storage.set("bookings-list", JSON.stringify(newList), true);
      setBookings(newList);
    } catch (err) {
      setStorageError(true);
    }
    setUpdatingId(null);
  }

  const myBookings = myIds
    .map((id) => bookings.find((b) => b.id === id))
    .filter(Boolean);

  const filtered = filter === "all" ? bookings : bookings.filter((b) => b.status === filter);

  const counts = STATUS_ORDER.reduce((acc, s) => {
    acc[s] = bookings.filter((b) => b.status === s).length;
    return acc;
  }, {});

  return (
    <div className="pl-app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

        .pl-app {
          --paper: #ECEAE2;
          --paper-alt: #E1DFD3;
          --ink: #16233D;
          --ink-soft: #4B5872;
          --amber: #E8A03C;
          --amber-deep: #C97F0E;
          --red: #B23A2E;
          --green: #2F6B4F;
          --line: #C9C4B4;
          font-family: 'IBM Plex Sans', sans-serif;
          background: var(--paper);
          color: var(--ink);
          border-radius: 14px;
          border: 1px solid var(--line);
          padding: 0;
          overflow: hidden;
        }
        .pl-app *, .pl-app *::before, .pl-app *::after { box-sizing: border-box; }
        .pl-app button, .pl-app input, .pl-app select, .pl-app textarea { font-family: inherit; }
        .pl-app :focus-visible { outline: 2px solid var(--ink); outline-offset: 2px; }

        .topbar {
          display: flex; align-items: center; justify-content: space-between;
          flex-wrap: wrap; gap: 12px;
          padding: 18px 24px; background: var(--ink); color: var(--paper);
        }
        .wordmark {
          font-family: 'Oswald', sans-serif; font-weight: 600; letter-spacing: 1.5px;
          font-size: 20px; text-transform: uppercase;
        }
        .wordmark span { color: var(--amber); }
        .tabs { display: flex; gap: 4px; background: rgba(255,255,255,0.08); padding: 4px; border-radius: 8px; }
        .tab {
          border: none; background: transparent; color: var(--paper); opacity: 0.75;
          font-family: 'Oswald', sans-serif; letter-spacing: 0.5px; text-transform: uppercase;
          font-size: 13px; padding: 8px 14px; border-radius: 6px; cursor: pointer;
        }
        .tab.active { background: var(--amber); color: var(--ink); opacity: 1; font-weight: 600; }
        .tab:hover:not(.active) { opacity: 1; }

        main { padding: 24px; }

        .section-title {
          font-family: 'Oswald', sans-serif; text-transform: uppercase; letter-spacing: 0.8px;
          font-size: 14px; color: var(--ink-soft); display: flex; align-items: center; gap: 8px;
          margin: 0 0 12px 0; padding-bottom: 8px; border-bottom: 1px dashed var(--line);
        }

        /* ---- book view ---- */
        .book-grid { display: grid; grid-template-columns: 1.3fr 1fr; gap: 24px; align-items: start; }
        @media (max-width: 820px) { .book-grid { grid-template-columns: 1fr; } }

        .form-panel {
          background: #fff; border: 1px solid var(--line); border-radius: 10px; padding: 20px;
          display: flex; flex-direction: column; gap: 20px;
        }
        .field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 10px; }
        @media (max-width: 480px) { .field-row { grid-template-columns: 1fr; } }
        .form-panel label {
          display: flex; flex-direction: column; gap: 6px; font-size: 12.5px;
          color: var(--ink-soft); font-weight: 500;
        }
        .form-panel input[type="text"], .form-panel input[type="tel"],
        .form-panel input[type="number"], .form-panel input[type="date"],
        .form-panel textarea {
          border: 1px solid var(--line); border-radius: 6px; padding: 9px 10px;
          font-size: 14px; color: var(--ink); background: var(--paper); resize: vertical;
        }
        .form-panel textarea { min-height: 56px; }
        .checkbox-label { flex-direction: row !important; align-items: center; gap: 8px !important; margin-top: 8px; }
        .checkbox-label input { width: 16px; height: 16px; }

        .chip-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }
        .chip {
          border: 1px solid var(--line); background: var(--paper); border-radius: 8px;
          padding: 8px 12px; cursor: pointer; text-align: left; display: flex; flex-direction: column;
          font-size: 13px; color: var(--ink); min-width: 96px;
        }
        .chip span { display: block; font-size: 11px; color: var(--ink-soft); margin-top: 2px; }
        .chip.active { background: var(--ink); border-color: var(--ink); color: var(--paper); }
        .chip.active span { color: var(--amber); }
        .chip:hover:not(.active) { border-color: var(--ink-soft); }

        .submit-btn {
          margin-top: 4px; background: var(--amber); color: var(--ink); border: none;
          border-radius: 8px; padding: 13px 18px; font-weight: 600; font-size: 14.5px;
          cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .submit-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .submit-btn:hover:not(:disabled) { background: var(--amber-deep); }
        .spin { animation: pl-spin 0.9s linear infinite; }
        @media (prefers-reduced-motion: reduce) { .spin { animation: none; } }
        @keyframes pl-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

        .confirm-banner {
          background: #fff; border: 1px solid var(--green); color: var(--green);
          border-radius: 8px; padding: 10px 14px; font-size: 13.5px; margin-bottom: 14px;
          font-weight: 500;
        }
        .confirm-banner strong { font-family: 'IBM Plex Mono', monospace; }

        /* ---- waybill ticket ---- */
        .waybill {
          position: relative; background: #fff; border: 1px solid var(--line); border-radius: 10px;
          padding: 22px; overflow: hidden;
        }
        .waybill-stamp {
          position: absolute; top: 18px; right: 16px; border: 3px solid; border-radius: 6px;
          padding: 4px 10px; font-family: 'Oswald', sans-serif; font-weight: 600; font-size: 12px;
          letter-spacing: 1.5px; transform: rotate(-8deg); opacity: 0.9;
        }
        .waybill-eyebrow {
          font-family: 'Oswald', sans-serif; text-transform: uppercase; letter-spacing: 2px;
          font-size: 11px; color: var(--ink-soft);
        }
        .waybill-tracking {
          font-family: 'IBM Plex Mono', monospace; font-size: 22px; font-weight: 600;
          margin: 4px 0 18px 0; max-width: 70%;
        }
        .waybill-route { display: flex; align-items: center; gap: 14px; margin-bottom: 16px; }
        .route-point { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
        .route-label { font-size: 10.5px; text-transform: uppercase; letter-spacing: 1px; color: var(--ink-soft); }
        .route-value { font-weight: 600; font-size: 14px; }
        .route-sub { font-size: 12px; color: var(--ink-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .route-arrow { color: var(--amber-deep); flex-shrink: 0; }

        .waybill-divider { position: relative; border-top: 2px dashed var(--line); margin: 16px -22px; }
        .notch { position: absolute; top: -9px; width: 18px; height: 18px; border-radius: 50%; background: var(--paper); }
        .notch.left { left: -9px; }
        .notch.right { right: -9px; }

        .waybill-meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 16px; margin-bottom: 16px; }
        .meta-label { display: block; font-size: 10.5px; text-transform: uppercase; letter-spacing: 1px; color: var(--ink-soft); }
        .meta-value { display: block; font-size: 13.5px; font-weight: 500; margin-top: 2px; }
        .meta-value.price { font-family: 'IBM Plex Mono', monospace; color: var(--amber-deep); font-weight: 600; }

        .barcode { display: flex; align-items: flex-end; gap: 2px; height: 32px; }
        .barcode span { display: inline-block; background: var(--ink); height: 100%; }

        /* ---- your bookings ---- */
        .my-bookings { margin-top: 28px; }
        .my-bookings h3 {
          font-family: 'Oswald', sans-serif; text-transform: uppercase; letter-spacing: 0.8px;
          font-size: 14px; color: var(--ink-soft); margin: 0 0 12px 0;
        }
        .mini-ticket-row { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 4px; }
        .mini-ticket {
          background: #fff; border: 1px solid var(--line); border-radius: 8px; padding: 12px 14px;
          min-width: 220px; flex-shrink: 0;
        }
        .mini-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 6px; }
        .mini-tracking { font-family: 'IBM Plex Mono', monospace; font-size: 13px; font-weight: 600; }
        .mini-stamp {
          border: 2px solid; border-radius: 4px; padding: 1px 6px; font-size: 9.5px;
          font-family: 'Oswald', sans-serif; letter-spacing: 0.8px; font-weight: 600; white-space: nowrap;
        }
        .mini-route { font-size: 12px; color: var(--ink-soft); margin-bottom: 2px; }
        .mini-slot { font-size: 11.5px; color: var(--ink-soft); }

        /* ---- dispatch view ---- */
        .stats-bar { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px; }
        .stat {
          background: #fff; border: 1px solid var(--line); border-radius: 8px; padding: 10px 16px;
          min-width: 100px; flex: 1;
        }
        .stat-count { display: block; font-family: 'Oswald', sans-serif; font-size: 22px; font-weight: 600; }
        .stat-label { display: block; font-size: 11.5px; color: var(--ink-soft); text-transform: uppercase; letter-spacing: 0.6px; margin-top: 2px; }

        .filter-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 16px; }
        .filter-chip {
          border: 1px solid var(--line); background: #fff; border-radius: 20px; padding: 6px 14px;
          font-size: 12.5px; cursor: pointer; color: var(--ink-soft);
        }
        .filter-chip.active { background: var(--ink); border-color: var(--ink); color: var(--paper); }

        .manifest-wrap { overflow-x: auto; }
        .manifest-table { min-width: 720px; }
        .manifest-header {
          display: grid; grid-template-columns: 1.1fr 1.6fr 1.3fr 1.3fr 1.1fr 1.2fr;
          gap: 10px; padding: 8px 14px; font-size: 11px; text-transform: uppercase;
          letter-spacing: 0.6px; color: var(--ink-soft); font-weight: 600;
        }
        .manifest-row { background: #fff; border: 1px solid var(--line); border-radius: 8px; margin-bottom: 8px; overflow: hidden; }
        .row-main {
          display: grid; grid-template-columns: 1.1fr 1.6fr 1.3fr 1.3fr 1.1fr 1.2fr;
          gap: 10px; align-items: center; padding: 12px 14px; cursor: pointer; font-size: 13px;
        }
        .row-main:hover { background: var(--paper); }
        .tracking-cell { font-family: 'IBM Plex Mono', monospace; font-weight: 600; }
        .route-cell { color: var(--ink-soft); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .pkg-cell, .slot-cell { color: var(--ink-soft); }
        .stamp-sm {
          display: inline-block; border: 2px solid; border-radius: 4px; padding: 2px 8px;
          font-family: 'Oswald', sans-serif; font-size: 10.5px; font-weight: 600; letter-spacing: 0.8px;
          width: fit-content;
        }
        .status-select {
          border: 1px solid var(--line); border-radius: 6px; padding: 6px 8px; font-size: 12px;
          background: var(--paper); color: var(--ink); cursor: pointer;
        }
        .row-detail {
          padding: 14px; border-top: 1px dashed var(--line); background: var(--paper);
          display: grid; grid-template-columns: 1fr 1fr; gap: 14px; font-size: 12.5px;
        }
        @media (max-width: 600px) { .row-detail { grid-template-columns: 1fr; } }
        .detail-block h4 { margin: 0 0 4px 0; font-size: 11px; text-transform: uppercase; letter-spacing: 0.6px; color: var(--ink-soft); }
        .detail-block p { margin: 0; line-height: 1.5; }
        .expand-icon { color: var(--ink-soft); display: flex; justify-content: flex-end; }

        .empty-state {
          text-align: center; padding: 40px 20px; color: var(--ink-soft); font-size: 13.5px;
          background: #fff; border: 1px dashed var(--line); border-radius: 10px;
        }
        .loading-state { display: flex; align-items: center; gap: 8px; color: var(--ink-soft); font-size: 13.5px; padding: 20px 0; }
        .storage-note { font-size: 11.5px; color: var(--ink-soft); margin-top: 16px; }
      `}</style>

      <header className="topbar">
        <div className="wordmark">PARCEL<span>LINE</span></div>
        <nav className="tabs">
          <button className={view === "book" ? "tab active" : "tab"} onClick={() => setView("book")}>
            Send a Parcel
          </button>
          <button className={view === "dispatch" ? "tab active" : "tab"} onClick={() => setView("dispatch")}>
            Dispatch Board
          </button>
        </nav>
      </header>

      <main>
        {loading ? (
          <div className="loading-state"><Loader2 size={16} className="spin" /> Loading bookings…</div>
        ) : view === "book" ? (
          <section>
            {confirmedTracking && (
              <div className="confirm-banner">
                Pickup booked. Tracking number <strong>{confirmedTracking}</strong> — find it under "Your bookings" below.
              </div>
            )}
            {storageError && (
              <div className="confirm-banner" style={{ borderColor: "var(--red)", color: "var(--red)" }}>
                Something went wrong saving that. Please try again.
              </div>
            )}

            <div className="book-grid">
              <form className="form-panel" onSubmit={handleSubmit}>
                <div>
                  <h2 className="section-title"><MapPin size={15} /> Pickup</h2>
                  <div className="field-row">
                    <label>Sender name
                      <input type="text" value={draft.senderName} onChange={(e) => setField("senderName", e.target.value)} placeholder="Full name" />
                    </label>
                    <label>Phone
                      <input type="tel" value={draft.senderPhone} onChange={(e) => setField("senderPhone", e.target.value)} placeholder="09XX XXX XXXX" />
                    </label>
                  </div>
                  <label>Pickup address
                    <textarea value={draft.senderAddress} onChange={(e) => setField("senderAddress", e.target.value)} placeholder="Street, barangay, city" />
                  </label>
                </div>

                <div>
                  <h2 className="section-title"><Truck size={15} /> Delivery</h2>
                  <div className="field-row">
                    <label>Receiver name
                      <input type="text" value={draft.receiverName} onChange={(e) => setField("receiverName", e.target.value)} placeholder="Full name" />
                    </label>
                    <label>Phone
                      <input type="tel" value={draft.receiverPhone} onChange={(e) => setField("receiverPhone", e.target.value)} placeholder="09XX XXX XXXX" />
                    </label>
                  </div>
                  <label>Delivery address
                    <textarea value={draft.receiverAddress} onChange={(e) => setField("receiverAddress", e.target.value)} placeholder="Street, barangay, city" />
                  </label>
                </div>

                <div>
                  <h2 className="section-title"><Package size={15} /> Package</h2>
                  <div className="chip-row">
                    {SIZES.map((s) => (
                      <button type="button" key={s.id} className={draft.size === s.id ? "chip active" : "chip"} onClick={() => setField("size", s.id)}>
                        {s.label}<span>{s.hint}</span>
                      </button>
                    ))}
                  </div>
                  <div className="field-row">
                    <label>Weight (kg)
                      <input type="number" min="0" step="0.1" value={draft.weight} onChange={(e) => setField("weight", e.target.value)} placeholder="e.g. 1.5" />
                    </label>
                    <label className="checkbox-label">
                      <input type="checkbox" checked={draft.fragile} onChange={(e) => setField("fragile", e.target.checked)} /> Fragile item
                    </label>
                  </div>
                  <div className="chip-row">
                    {SERVICES.map((s) => (
                      <button type="button" key={s.id} className={draft.service === s.id ? "chip active" : "chip"} onClick={() => setField("service", s.id)}>
                        {s.label}<span>{s.hint}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h2 className="section-title"><Clock size={15} /> Schedule pickup</h2>
                  <label style={{ marginBottom: 10 }}>Date
                    <input type="date" value={draft.date} onChange={(e) => setField("date", e.target.value)} />
                  </label>
                  <div className="chip-row">
                    {SLOTS.map((s) => (
                      <button type="button" key={s.id} className={draft.slot === s.id ? "chip active" : "chip"} onClick={() => setField("slot", s.id)}>
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>

                <label>Notes (optional)
                  <textarea value={draft.notes} onChange={(e) => setField("notes", e.target.value)} placeholder="Gate code, landmark, handling instructions…" />
                </label>

                <button type="submit" className="submit-btn" disabled={!isValid || submitting}>
                  {submitting ? <Loader2 size={16} className="spin" /> : <Send size={16} />}
                  {isValid ? `Book pickup — est. ₱${price}` : "Fill in required fields"}
                </button>
              </form>

              <aside>
                <Waybill booking={previewBooking} draftMode />
              </aside>
            </div>

            {myBookings.length > 0 && (
              <div className="my-bookings">
                <h3>Your bookings</h3>
                <div className="mini-ticket-row">
                  {myBookings.map((b) => <MiniTicket key={b.id} booking={b} />)}
                </div>
              </div>
            )}
          </section>
        ) : (
          <section>
            <div className="stats-bar">
              {STATUS_ORDER.map((s) => (
                <div className="stat" key={s}>
                  <span className="stat-count">{counts[s]}</span>
                  <span className="stat-label">{STATUS_META[s].label}</span>
                </div>
              ))}
            </div>

            <div className="filter-row">
              <button className={filter === "all" ? "filter-chip active" : "filter-chip"} onClick={() => setFilter("all")}>
                All ({bookings.length})
              </button>
              {STATUS_ORDER.map((s) => (
                <button key={s} className={filter === s ? "filter-chip active" : "filter-chip"} onClick={() => setFilter(s)}>
                  {STATUS_META[s].label} ({counts[s]})
                </button>
              ))}
            </div>

            {filtered.length === 0 ? (
              <div className="empty-state">No bookings match this filter yet.</div>
            ) : (
              <div className="manifest-wrap">
                <div className="manifest-table">
                  <div className="manifest-header">
                    <span>Tracking</span><span>Route</span><span>Package</span><span>Pickup</span><span>Status</span><span>Update</span>
                  </div>
                  {filtered.map((b) => {
                    const meta = STATUS_META[b.status] || STATUS_META.pending;
                    const sizeInfo = SIZES.find((s) => s.id === b.pkg?.size);
                    const serviceInfo = SERVICES.find((s) => s.id === b.pkg?.service);
                    const slotInfo = SLOTS.find((s) => s.id === b.slot);
                    const expanded = expandedId === b.id;
                    return (
                      <div className="manifest-row" key={b.id}>
                        <div className="row-main" onClick={() => setExpandedId(expanded ? null : b.id)}>
                          <span className="tracking-cell">{b.tracking}</span>
                          <span className="route-cell">{cityOf(b.sender?.address)} → {cityOf(b.receiver?.address)}</span>
                          <span className="pkg-cell">{sizeInfo?.label}{serviceInfo ? ` · ${serviceInfo.label}` : ""}</span>
                          <span className="slot-cell">{formatDate(b.date)}{slotInfo ? ` · ${slotInfo.label}` : ""}</span>
                          <span className="stamp-sm" style={{ color: meta.color, borderColor: meta.color }}>{meta.stamp}</span>
                          <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            <select
                              className="status-select"
                              value={b.status}
                              onClick={(e) => e.stopPropagation()}
                              onChange={(e) => updateStatus(b.id, e.target.value)}
                              disabled={updatingId === b.id}
                            >
                              {STATUS_ORDER.map((s) => <option key={s} value={s}>{STATUS_META[s].label}</option>)}
                            </select>
                            {updatingId === b.id ? <Loader2 size={14} className="spin" /> : (expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />)}
                          </span>
                        </div>
                        {expanded && (
                          <div className="row-detail">
                            <div className="detail-block">
                              <h4>Sender</h4>
                              <p>{b.sender?.name}{b.sender?.phone ? ` · ${b.sender.phone}` : ""}</p>
                              <p>{b.sender?.address}</p>
                            </div>
                            <div className="detail-block">
                              <h4>Receiver</h4>
                              <p>{b.receiver?.name}{b.receiver?.phone ? ` · ${b.receiver.phone}` : ""}</p>
                              <p>{b.receiver?.address}</p>
                            </div>
                            <div className="detail-block">
                              <h4>Package</h4>
                              <p>{sizeInfo?.label}{b.pkg?.weight ? `, ${b.pkg.weight}kg` : ""}{b.pkg?.fragile ? " · Fragile" : ""}</p>
                              <p>Est. rate: ₱{b.price || 0}</p>
                            </div>
                            <div className="detail-block">
                              <h4>Notes</h4>
                              <p>{b.notes || "—"}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            <p className="storage-note"><RefreshCw size={11} style={{ verticalAlign: "-1px", marginRight: 4 }} />Bookings are shared demo data — visible to anyone using this app.</p>
          </section>
        )}
      </main>
    </div>
  );
}
