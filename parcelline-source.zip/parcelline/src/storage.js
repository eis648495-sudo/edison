// Drop-in replacement for the Claude-artifact `window.storage` API,
// backed by the browser's localStorage so the app works once deployed
// outside of Claude.ai. Data is per-browser, not shared across visitors.

const storage = {
  async get(key) {
    const raw = localStorage.getItem(key);
    if (raw === null) {
      throw new Error(`Key not found: ${key}`);
    }
    return { key, value: raw };
  },

  async set(key, value) {
    localStorage.setItem(key, value);
    return { key, value };
  },

  async delete(key) {
    const existed = localStorage.getItem(key) !== null;
    localStorage.removeItem(key);
    return { key, deleted: existed };
  },

  async list(prefix = "") {
    const keys = Object.keys(localStorage).filter((k) => k.startsWith(prefix));
    return { keys, prefix };
  },
};

export default storage;
